#Rezvee Rahman
#CSC212-03 Data Structures
#Project 4: Pet classes part 2
from typing import Counter
import PetClass
import readFile

def main():
    while True:
        print("Select the corresponding choices for the menu\n")
        print("1 - Load Pets\n2 - Exit")
        try:
            choice = int(input("Enter your choice: "))
        except ValueError:
            print("\nPlease enter a number")

        if(choice == 1):
            #Retrieve the pet data
            print("Retrieving data...")

            #Makesure to create a list for storing pets objects
            List_of_Pet_obj = []
            
            #Read the file and return it to a variable
            Storage_data = readFile.lineReturner(readFile.readfile_())
            
            #Take that file and init objects from Pet class
            for _ in Storage_data:
                name = str(_[0]).replace('_',' ')
                species = str(_[1]).replace('_',' ')
                family = str(_[2]).replace('_',' ')
                owner = str(_[3]).replace('_',' ')

                #List of Obj will append every pet
                Temp_holder = PetClass.Pets(name, family, species, owner)
                List_of_Pet_obj.append([Temp_holder.get_pet_name(), Temp_holder.get_pet_family(), Temp_holder.get_pet_species(), Temp_holder.get_pet_owner()])
                
            #Print out the final result
            print(List_of_Pet_obj)
            Temp_holder = []

            while True:
                print("\nWould you like to find a specific entry on the list?")
                print("1 - Pet name\n2 - Species\n3 - family\n4 - Owner\n5 - Main Menu")
                try:
                    choice_2 = int(input("\nPlease enter an integer corresponding with the menu numbers: "))
                except ValueError:
                    print("\nEntry must be an integer.")

                Counter = 0
                search = None

                if(choice_2 == 1):
                    print("Please print the name of the pet.")
                    search = input("Insert Pet name (case sensitive): ")
                    for i in List_of_Pet_obj:
                        if (i[0] == search):
                            print("\nThe owner of {} is {}".format(i[0],i[3]))
                            input("Press enter to continue.")
                    
                elif(choice_2 == 2):
                    print("Please print the species to find certain pets that fall under the category.")
                    search = input("Please print the species to find who owns this type owns this type of pet: ")
                    for i in List_of_Pet_obj:
                        if (i[1].lower() == search.lower()):
                            print("\n{} owns a pet called {}. This pet is from the species {}.".format(i[3],i[0],i[1]))
                            input("Press enter to continue.")
                            Counter += 1

                    print("\nThere are {} that owns this type of pet species".format(Counter))



                elif(choice_2 == 3):
                    print("Please print the pet species you want to find and get a return of the pets under that species: ")
                    search = input("Please print the family to see who owns this type of pet")
                    for i in List_of_Pet_obj:
                        if (i[2].lower() == search.lower()):
                            print("\n{} has pet called {} which from the family {}.".format(i[3],i[0],i[2]))
                            input("Press enter to continue.")
                            Counter += 1

                    print("\nThere are {} that owns this type of pet family.".format(Counter))



                elif(choice_2 == 4):
                    print("Please print the owners to find the pet corresponding with them.")
                    search = input("Please print the owner to find what pet they own[Case sensitive]: ")

                    for i in List_of_Pet_obj:
                        if(i[3] == search):
                            print("\n{} is the owner of {}".format(i[3], i[0]))
                            input("Press enter to continue.")
                            break

                elif(choice_2 == 5):
                    break
                else:
                    print("Please enter a number that corresponds with menu choices.")




        elif(choice == 2):
            print("Exiting")
            break
        else:
            print("The choice could not be processed please try aagain. ")
    pass

if __name__ == "__main__":
    main()
