#Rezvee Rahman

class Pets:
    def __init__(self, pet_name, pet_species, pet_family, pet_owner) -> None: #Returns no value
        #If for what ever reason we are going to be using this class again, we have double underscores in the beginning to avoid naming conflicts
        self.__pet_name = pet_name 
        self.__pet_species = pet_species
        self.__pet_family = pet_family
        self.__pet_owner = pet_owner
        pass

    #__STR__ How our class is going to be viewed
    def __str__(self) -> str:
        return "{} is a {} species from the family {}. This pet is owned by {}.".format(self.get_pet_name(), self.get_pet_species(), self.get_pet_family(), self.get_pet_owner())

    #Setters
    #All of the setters will return a string value for the instantiation
    def set_pet_name(self, pet_name):
        self.__pet_name = pet_name
    
    def set_pet_species(self, pet_species):
        self.__pet_species = pet_species
    
    def set_pet_family(self, pet_family):
        self.__pet_family = pet_family
    
    def set_pet_owner(self, pet_owner):
        self.__pet_owner = pet_owner
    
    #Getters
    #Getters will just display values
    def get_pet_name(self):
        return self.__pet_name
    
    def get_pet_species(self):
        return self.__pet_species

    def get_pet_family(self):
        return self.__pet_family

    def get_pet_owner(self):
        return self.__pet_owner


