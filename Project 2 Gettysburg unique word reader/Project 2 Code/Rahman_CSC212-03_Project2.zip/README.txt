Rezvee Rahman

This file will only require one dependency which is the lineReader.py. The main file execution is mainWordExecution.